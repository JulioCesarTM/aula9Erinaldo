const express = require("express"); // puxando esse negocio express e colocando na const express
const app = express(); //a const app esta se tranformando em uma instancia de express , se tranformando em um objeto.

app.get("/",(req,res) => {
    res.send("Boas práticas de organização!"); // agora o app e um objeto e pode acessar as funcoes existentes como a função get que busca ou manda informações para site
});

app.listen (3000, ()=>{
    console.log("Servidor rodando na porta 3000"); //aqui usa a função listen onde fica "ouvindo quando tem uma requisição"
});